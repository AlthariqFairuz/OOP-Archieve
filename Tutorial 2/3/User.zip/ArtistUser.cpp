#include "ArtistUser.h"
#include <iostream>
using namespace std;
int ArtistUser::num_of_artist = 0;

ArtistUser::ArtistUser(char *nama) : User(nama)
{
    num_of_music_uploaded = 0;
    uploaded_music_list = new char *[100];
    num_of_artist++;
}

ArtistUser::ArtistUser(const ArtistUser &user) : User(user)
{
    num_of_music_uploaded = user.num_of_music_uploaded;
    uploaded_music_list = new char *[100];
    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        uploaded_music_list[i] = user.uploaded_music_list[i];
    }
    num_of_artist++;
}

ArtistUser ::~ArtistUser()
{
    delete[] uploaded_music_list;
    num_of_artist--;
    cout << "Artist user " << getName() << " deleted" << endl;
}

void ArtistUser ::uploadMusic(char *music)
{
    uploaded_music_list[num_of_music_uploaded] = music;
    num_of_music_uploaded++;
}

void ArtistUser ::deleteUploadedMusic(char *music)
{
    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        if (strcmp(uploaded_music_list[i], music) == 0)
        {
            for (int j = i; j < num_of_music_uploaded; j++)
            {
                uploaded_music_list[j] = uploaded_music_list[j + 1];
            }
            num_of_music_uploaded--;
            break;
        }
    }
}

void ArtistUser ::viewUploadedMusicList() const
{
    if (num_of_music_uploaded == 0)
    {
        cout << "No music uploaded" << endl;
    }
    else
    {
        for (int i = 0; i < num_of_music_uploaded; i++)
        {
            cout << i + 1 << ". " << uploaded_music_list[i] << endl;
        }
    }
}

int ArtistUser ::getNumOfMusicUploaded() const
{
    return num_of_music_uploaded;
}

int ArtistUser ::getNumOfArtist()
{
    return num_of_artist;
}
